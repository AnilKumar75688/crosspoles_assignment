<!DOCTYPE html>
<html>
<head>
    <title>User List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<meta name="csrf-token" content="{{ csrf_token() }}" />
</head>
      
<body>
<div class="container">
       
    <div class="panel panel-primary">
  
      <div class="panel-heading">
        <h2 style="text-align: center;">Laravel 8 User List</h2>
      </div>
  
      <div class="panel-body">
       
        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block">
                <strong>{{ $message }}</strong>
            </div>
        @endif
      	<div class="row">
      		<div class="col-md-6">
      			<form id="regsiter_form" method="POST" enctype="multipart/form-data">
		            @csrf
		  			<div class="mb-3">
		                <label class="form-label" for="inputFile">Name:</label>
		                <input type="text" name="name" class="form-control" placeholder="Enter Name" id="name">
		                <span class="text-danger" id="name-error"></span>
		            </div>

		            <div class="mb-3">
		                <label class="form-label" for="inputFile">Email:</label>
		                <input type="text" name="email" class="form-control" placeholder="Enter Email" id="email">
            			<span class="text-danger" id="email-error"></span>
		            </div>

		            <div class="mb-3">
		                <label class="form-label" for="inputFile">Phone:</label>
		  					 <input type="text" name="phone" class="form-control" placeholder="Enter Mobile Number" id="mobile-number" pattern="\d{10}" title="Error: 10 digits are required." onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode &gt;= 48 && event.charCode &lt;= 57" maxlength="10"> 
           				 	<span class="text-danger" id="mobile-number-error"></span>
		            </div>

		            <div class="mb-3">
						<label for="country">Country:</label>
						<select class="form-control" id="country-dropdown" name="country">
							<option value="">Select Country</option>
							@foreach ($countries as $country) 
								<option value="{{$country->id}}">
									{{$country->name}}
								</option>
							@endforeach
						</select>
            			<span class="text-danger" id="country-error"></span>
		            </div>

		            <div class="mb-3">
						<label for="country">State</label>
						<select class="form-control" id="state-dropdown" name="state">
						</select>
		                <span class="text-danger" id="state-error"></span>
		            </div>

		            <div class="mb-3">
						<label for="country">City</label>
						<select class="form-control" id="city-dropdown" name="city">
						</select>
		                <span class="text-danger" id="city-error"></span>
		       
		            </div>

		            <div class="mb-3">
		                <label class="form-label" for="inputFile">Profile Image:</label>
		                <input 
		                    type="file" 
		                    name="profile" 
		                    id="profile" 
		                    class="form-control @error('name') is-invalid @enderror">
		  					<span class="text-danger" id="profile-error"></span>
		                
		            </div>
		   			
		            <div class="mb-3">
		                <button class="btn btn-success" id="submit">Submit</button>
		                <button type="reset" class="btn btn-success">Cancel</button>
		            </div>
        		</form>
      		</div>

      		<div class="col-md-6">
      			<h1 style="text-align:center;">User List</h1>
      			<table class="table table-bordered">
      				<tr>
      					<td>S.No</td>
      					<td>Name</td>
      					<td>Email</td>
      					<td>Phone</td>
      					<td>Country</td>
      					<td>State</td>
      					<td>City</td>
      					<td>Profile</td>
      				</tr>
      				<tr>
      					@foreach($users as $u_info)
			              <tr id="user_id_{{ $u_info->id }}">
			                 <td>{{ $u_info->id  }}</td>
			                 <td>{{ $u_info->name }}</td>
			                 <td>{{ $u_info->email }}</td>
			                 <td>{{ $u_info->phone }}</td>
			                 <td>
			                 	<?php 
			                 	$helper =  new App\Helpers;
			                 	$image = $u_info->profile;
			                 	echo $country_name = $helper->get_country_name($u_info->country); ?>
			                 </td>
			                 <td><?=  $state_name = $helper->get_state_name($u_info->state); ?></td>
			                 <td><?=  $city_name = $helper->get_city_name($u_info->city); ?></td>
			                 <td>
			                 	<img src="{{asset('public/profile/'.$image)}}" width="100" 
                class="img-fluid img-thumbnail"></td>
			              </tr>
			              @endforeach
      				</tr>
      			</table>

      		</div>
      		
      	</div>


       
      
      </div>
    </div>
</div>
</body>
<script>
	$(document).ready(function() {
		$('#country-dropdown').on('change', function() {
			var country_id = this.value;
			$("#state-dropdown").html('');
			$.ajax({
				url:"{{url('get-states-by-country')}}",
				type: "POST",
				data: {
					country_id: country_id,
					_token: '{{csrf_token()}}' 
				},
			dataType : 'json',
			success: function(result){
				$('#state-dropdown').html('<option value="">Select State</option>'); 
				$.each(result.states,function(key,value){
					$("#state-dropdown").append('<option value="'+value.id+'">'+value.name+'</option>');
				});
				$('#city-dropdown').html('<option value="">Select State First</option>'); 
			}
			});
		});
		$('#state-dropdown').on('change', function() {
			var state_id = this.value;
			$("#city-dropdown").html('');
			$.ajax({
				url:"{{url('get-cities-by-state')}}",
				type: "POST",
				data: {
					state_id: state_id,
					_token: '{{csrf_token()}}' 
				},
				dataType : 'json',
				success: function(result){
					$('#city-dropdown').html('<option value="">Select City</option>'); 
					$.each(result.cities,function(key,value){
					$("#city-dropdown").append('<option value="'+value.id+'">'+value.name+'</option>');
				});
				}
			});
		});
	});  

</script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>

   <script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#regsiter_form').on('submit', function(event){
        $('#name-error').text('');
        $('#email-error').text('');
        $('#mobile-number-error').text('');
        $('#country-error').text('');
        $('#state-error').text('');
        $('#city-error').text('');
        $('#profile-error').text('');

        name = $('#name').val();
        email = $('#email').val();
        mobile_number = $('#mobile-number').val();
        country = $('#country-dropdown').val();
        state = $('#state-dropdown').val();
        city = $('#city-dropdown').val();
        profile = $("#profile").val();


        event.preventDefault();
		var formData = new FormData(this);



        $.ajax({
          url: "{{ url('regsiter_save') }}",
          type: "POST",
          // data:{
          //     name:name,
          //     email:email,
          //     phone:mobile_number,
          //     country:country,
          //     state:state,
          //     city:city,
          //     profile:profile,
          // },
          data: formData,
		  cache:false,
		  contentType: false,
		  processData: false,
          success:function(response){
            console.log(response);
            if (response) {
              $('#success-message').text(response.success);
              $("#regsiter_form")[0].reset();
              location.reload();
            }
          },
          error: function(response) {
              $('#name-error').text(response.responseJSON.errors.name);
              $('#email-error').text(response.responseJSON.errors.email);
              $('#mobile-number-error').text(response.responseJSON.errors.mobile_number);
              $('#country-error').text(response.responseJSON.errors.country);
              $('#state-error').text(response.responseJSON.errors.state);
              $('#city-error').text(response.responseJSON.errors.city);
              $('#profile-error').text(response.responseJSON.errors.profile);
          }
         });
        });
      </script>
    
</html>