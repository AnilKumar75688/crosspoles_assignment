<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\{Country,State,City,NewUsers};

class UsersController extends Controller{
    
    public function index(){
        $data['countries'] = Country::get(["name","id"]);
        $data['users'] = NewUsers::orderBy('id','asc')->get();
        return view('user_list',$data);
    }
    public function getState(Request $request){
        $data['states'] = State::where("country_id",$request->country_id)->get(["name","id"]);
        return response()->json($data);
    }
    public function getCity(Request $request){
        $data['cities'] = City::where("state_id",$request->state_id)->get(["name","id"]);
        return response()->json($data);
    }

    public function regsiter_save(Request $request){
        $fileName = '';
        $request->validate([
             'name'           => 'required',
             'email'          => 'required|email',
             'phone'          => 'required|numeric',
             'country'        => 'required',
             'state'          => 'required',
             'city'           => 'required',
             'profile'        => 'required',
         ]);
        $profile_img = $request->file('profile');
        //dd($profile_img);
        if($profile_img!=""){
            $fileName = time().$profile_img->getClientOriginalName();
            $profile_img->move(public_path().'/profile', $fileName);
        }
        NewUsers::create([
            'name'          => $request->name,
            'email'         => $request->email,
            'phone'         => $request->phone,
            'country'       => $request->country,
            'state'         => $request->state,
            'city'          => $request->city,
            'profile'       => $fileName,
        ]);
        return response()->json([ 'success'=> 'Form is successfully submitted!']);
    }



}
